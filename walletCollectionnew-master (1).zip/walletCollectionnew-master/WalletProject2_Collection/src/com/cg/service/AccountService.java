package com.cg.service;
import java.util.Map;

import com.cg.bean.Account;
import com.cg.dao.AccountDAO;
import com.cg.dao.AccountDAOImpl;
import com.cg.exception.InsuffecientFundException;
public class AccountService implements Transaction {

	
	AccountDAO dao = new AccountDAOImpl();
	@Override
	public double withdraw(Account ob, double amount) throws InsuffecientFundException {
		// TODO Auto-generated method stub
		double new_balance=ob.getBalance()-amount;
		if(new_balance<1000.0 || amount<0)
		{
			new_balance=ob.getBalance();
			throw new InsuffecientFundException("Insufficient fund. Can not process withdrawal",new_balance);
		}
		String report=Double.toString(amount)+" Withdrawed";
		dao.addprint(ob.getAid(), report);
		ob.setBalance(new_balance);
		dao.updateAccount(ob);
		return new_balance;
	}


	@Override
	public double Deposit(Account ob, double amount) throws InsuffecientFundException {
		double new_balance=ob.getBalance()+amount;
		if(amount<0)
		{
			new_balance=ob.getBalance();
			throw new InsuffecientFundException("Invalid amount to be added",amount);
		}
		String report=Double.toString(amount)+" deposited";
		dao.addprint(ob.getAid(), report);
		ob.setBalance(new_balance);
		dao.updateAccount(ob);
		return new_balance;
	}

	

	@Override
	public void addAccount(Account ob) {
		// TODO Auto-generated method stub
		 dao.addAccount(ob);
	}


	@Override
	public Account findAccount(int accno) {
		// TODO Auto-generated method stub
		return dao.findAccount(accno);
	}

	@Override
	public Map<Integer, Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return dao.getAllAccounts();
	}

	@Override
	public boolean updateAccount(Account ob) {
		// TODO Auto-generated method stub
		return dao.updateAccount(ob);
	}

	@Override
	public double TransferMoney(Account from, Account to, double amount) throws InsuffecientFundException {
		// TODO Auto-generated method stub
		
		return dao.TransferMoney(from, to, amount);
	}


	public void getstatement(int id) {
		// TODO Auto-generated method stub
		dao.getstatement(id);
	}

	
	

}
